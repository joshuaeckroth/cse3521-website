from paip.gps import gps

problem = {
    "start": ["hungry", "have money"],
    "finish": ["satiated"],
    "ops": [
        {
            "action": "prepare food",
            "preconds": ["have food", "have microwave"],
            "add": ["food is ready"],
            "delete": ["have food"]
            },
        {
            "action": "buy food",
            "preconds": ["have money"],
            "add": ["have food"],
            "delete": ["have money"]
            },
        {
            "action": "eat prepared food",
            "preconds": ["food is ready"],
            "add": ["satiated"],
            "delete": ["hungry", "food is ready"]
            }
        ]
    }

def main():
    start = problem['start']
    finish = problem['finish']
    ops = problem['ops']
    for action in gps(start, finish, ops):
        print action

if __name__ == '__main__':
    main()










