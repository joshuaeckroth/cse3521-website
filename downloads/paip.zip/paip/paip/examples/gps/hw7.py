from paip.gps import gps

problem = {
    "start": [],
    "finish": [],
    "ops": []
}

def main():
    start = problem['start']
    finish = problem['finish']
    ops = problem['ops']
    for action in gps(start, finish, ops):
        print action

if __name__ == '__main__':
    main()
