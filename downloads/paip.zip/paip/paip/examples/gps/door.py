from paip.gps import gps

problem = {
    "start": ["door closed", "door locked"],
    "finish": ["door open"],
    "ops": [
        {
            "action": "open door",
            "preconds": ["door unlocked", "door closed"],

            "add": ["door open"],
            "delete": ["door closed"]
            },
        {
            "action": "unlock door",
            "preconds": ["door closed"],
            "add": ["door unlocked"],
            "delete": ["door locked"]
            }
        ]
    }

def main():
    start = problem['start']
    finish = problem['finish']
    ops = problem['ops']
    for action in gps(start, finish, ops):
        print action

if __name__ == '__main__':
    main()
