package ai;

import java.awt.event.KeyEvent;

import com.googlecode.javacpp.Loader;
import com.googlecode.javacv.*;
import com.googlecode.javacv.cpp.*;
import com.googlecode.javacv.cpp.opencv_core.CvArr;
import com.googlecode.javacv.cpp.opencv_video.BackgroundSubtractorMOG;

import static com.googlecode.javacv.cpp.opencv_core.*;
import static com.googlecode.javacv.cpp.opencv_imgproc.*;
import static com.googlecode.javacv.cpp.opencv_highgui.*;
import static com.googlecode.javacv.cpp.opencv_objdetect.*;

import com.googlecode.javacv.OpenCVFrameGrabber;

public class Track {

	public static void main(String[] args) throws Exception {
		CanvasFrame frame = new CanvasFrame("Track");
		
		OpenCVFrameGrabber grabber = OpenCVFrameGrabber.createDefault("../track/Balcony4_Vis.mpg");
		grabber.start();
		BackgroundSubtractorMOG backsub = new BackgroundSubtractorMOG();
		CvMemStorage storage = CvMemStorage.create();
		
		while(true) {
			IplImage img = grabber.grab();
			IplImage fgmask = cvCreateImage(cvGetSize(img), IPL_DEPTH_8U, 1);
			backsub.apply(img, fgmask, 0.01);
			
			CvSeq contours = new CvSeq();
			cvFindContours(fgmask, storage, contours, Loader.sizeof(CvContour.class), CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
			while(contours != null && !contours.isNull()) {
				CvRect box = cvBoundingRect(contours, 0);
				if(box.width() > 10 && box.height() > 10) {
					cvRectangle(img, new CvPoint(box.x(), box.y()),
							new CvPoint(box.x()+box.width(), box.y()+box.height()),
							new CvScalar(255), 2, 8, 0);
				}
				contours = contours.h_next();
			}
			frame.showImage(img);
			
			KeyEvent key = frame.waitKey(10);
			if(key != null && key.getKeyChar() == 'q') {
				System.exit(0);
			}
		}
	}
}
