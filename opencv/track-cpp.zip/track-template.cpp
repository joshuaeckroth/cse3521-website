#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include "opencv2/video/video.hpp"

#include <iostream>
#include <stdio.h>
#include <string>
#include <cmath>

using namespace std;
using namespace cv;

int main(int argc, const char** argv)
{
    CvCapture* capture;
    Mat frame;
    BackgroundSubtractorMOG backsub;

    vector<Point> locations;
    vector<int> last_seen;

    //capture = cvCaptureFromCAM(-1);
    capture = cvCaptureFromFile("Balcony4_Vis.mpg");
    if(capture)
    {
        // keep track of "time" (frame count)
        int t = 0;
        while(true)
        {
            // grab the next frame (an image)
            frame = cvQueryFrame(capture);

            if(!frame.empty())
            {
                // make a copy of the frame
                Mat fgmask = frame.clone();
                // perform background subtraction; adjust the 0.05 to
                // change the degree of "learning" -- higher
                // "learning" means more previous frames are
                // remembered
                backsub(frame, fgmask, 0.05);

                vector<vector<Point> > contours;
                findContours(fgmask, contours, CV_RETR_EXTERNAL, CV_CHAIN_APPROX_NONE);
                vector<vector<Point> >::const_iterator it = contours.begin();
                while(it != contours.end()) {
                    Rect box = boundingRect(Mat(*it));
                    if(box.width > 5 && box.height > 5) {
                        // draw rectangle on the frame
                        rectangle(frame, box, Scalar(255), 2);

                        // figure out id
                        char *best_id = new char[10];
                        .....


                        // draw id on the frame (you create the
                        // variable "best_id" which should be a C-style
                        // string (char*))
                        putText(frame, best_id, Point(box.x, box.y-5), 
                                FONT_HERSHEY_SIMPLEX, 0.5, Scalar(255), 2);
                    }
                    ++it;
                }
                // also draw the contours, for fun
                drawContours(frame, contours, -1, Scalar(255), 1);

                // show the frame
                imshow("Track", frame);

                // keep track of "time" (frame count)
                t++;
            }
            else
            { printf(" --(!) No captured frame -- Break!"); break; }

            int key = waitKey(10);
            if((char)key == 'q') { break; }
        }
    }
    return 0;
}


